package wrongpowder.io.osc.wii;

import java.lang.Enum;

public enum NunchukButton {
	C{
		public String toString(){
			return "C";
		}
	},
	Z{
		public String toString(){
			return "Z";
		}
	}
}
